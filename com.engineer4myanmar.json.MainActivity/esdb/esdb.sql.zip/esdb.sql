-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 07, 2015 at 10:54 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `esdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `info_id`) VALUES
(1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `name`) VALUES
(1, 'hotel'),
(2, 'bank'),
(3, 'restaurant'),
(4, 'hospital');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `time` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `history`
--


-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `hospital_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `price_high` decimal(10,2) NOT NULL,
  `price_low` decimal(10,2) NOT NULL,
  PRIMARY KEY (`hospital_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `info_id`, `price_high`, `price_low`) VALUES
(1, 7, '150.00', '50.00');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
  `hotel_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `price_high` decimal(10,2) NOT NULL,
  `price_low` decimal(10,2) NOT NULL,
  `cuisine` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotel_id`, `info_id`, `price_high`, `price_low`, `cuisine`) VALUES
(1, 3, '100.00', '10.00', 'Burmese, Chinese, Thai'),
(3, 8, '100.00', '10.00', 'chinese');

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE IF NOT EXISTS `information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(6) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(125) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(2) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `ext_tb` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`id`, `cat_id`, `name`, `address`, `phone_no`, `url`, `rating`, `lat`, `lng`, `ext_tb`) VALUES
(3, 1, 'Aster Hotel', 'No.47/48 Mandalay Lashio Rd POL', '09253614647', 'www.agoda.com/Malang-Hotels', 2, 22.007845, 96.435928, 'hotel'),
(5, 2, 'Yoma Bank', 'No.3 Mandalay Lashio Rd POL', '085-22658', 'www.yomabank.com', 2, 22.024990, 96.461311, 'bank'),
(6, 3, 'Unicorn restaurant', 'Mandalay Lashio Road', '09796655847', '', 3, 22.015629, 96.448929, 'restaurant'),
(7, 4, 'General Hospital', 'No.158-B/5 Mandalay Lashio Rd POL', '085-65489', '', 3, 22.022306, 96.464417, 'hospital'),
(8, 1, 'pyin oo lwin', 'No4. shwe tg road', '409511212', 'njfdjfhdjfh', 3, 545.154419, 254.155502, 'hotel');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `res_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `price_high` decimal(10,2) NOT NULL,
  `price_low` decimal(10,2) NOT NULL,
  `cuisine` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`res_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`res_id`, `info_id`, `price_high`, `price_low`, `cuisine`) VALUES
(1, 6, '100.00', '10.00', 'Burmese, Chinese, Thai, Japan');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_email` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_password` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_phoneno` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_dob` date NOT NULL,
  `user_profession` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_city` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_phoneno`, `user_dob`, `user_profession`, `user_city`) VALUES
(1, 'aung', 'aung@gmail.com', '12345', '095506082', '1978-02-19', 'student', 'yangong'),
(2, 'koko', 'koko@gmail.com', '11111', '095506083', '1888-12-19', 'student', 'mandalay'),
(44, 'yezaw', 'yezaw@gmail.com', '12345', '56678888', '2015-07-06', 'doctor', 'ygn'),
(46, 'yezawmyint', 'yezaw@gmail.com', '12345', '0933327917', '1983-07-06', 'student', 'pyinoolwin'),
(47, 'soethant', 'soe@gmail.com', '123456', '2058054', '2015-03-20', 'dr', 'maymyo'),
(48, 'agag', 'ag@gmail.com', '12345', '098766544', '2015-07-07', 'dr', 'ygn'),
(49, 'phoneko', 'phoneko@gmail.com', '12345', '557788', '2015-06-07', 'doctor', 'ygn');
