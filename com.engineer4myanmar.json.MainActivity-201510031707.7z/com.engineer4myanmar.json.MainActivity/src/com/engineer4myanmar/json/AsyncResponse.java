package com.engineer4myanmar.json;

public interface AsyncResponse {
	void processFinish(String output);
}
