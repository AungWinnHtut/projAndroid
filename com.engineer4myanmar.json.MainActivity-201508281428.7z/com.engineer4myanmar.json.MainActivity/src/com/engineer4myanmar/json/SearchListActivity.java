package com.engineer4myanmar.json;

import java.util.ArrayList;
import java.util.HashMap;


import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.support.v4.app.NavUtils;

public class SearchListActivity extends Activity {
	ArrayList<HashMap<String, String>> arl=new ArrayList<HashMap<String, String>>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		arl = (ArrayList<HashMap<String, String>>) getIntent()
				.getSerializableExtra("arraylist");
		//for (int i = 0; i < arl.size(); i++) {
		//	Toast.makeText(getApplicationContext(), arl.get(i).get("info_name"), Toast.LENGTH_SHORT).show();
		//}
		
		setContentView(R.layout.activity_search_list);
		ListView lv = (ListView)findViewById(R.id.lvList);
		ListAdapter adapter = new SimpleAdapter(
				this, arl,
				R.layout.list_item, new String[] { "info_name","address","phone_no"},
				new int[] { R.id.info_name, R.id.address,R.id.phone_no });
		// updating listview
		
		lv.setAdapter(adapter);
		
		
		lv.setOnItemClickListener(new OnItemClickListener() {
			  public void onItemClick(AdapterView<?> parent, View v, int position,
					long id) {
				
				
			}
			}); 


	}

}
