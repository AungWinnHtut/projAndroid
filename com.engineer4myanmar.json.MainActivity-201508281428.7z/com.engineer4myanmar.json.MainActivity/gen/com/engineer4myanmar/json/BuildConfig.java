/** Automatically generated file. DO NOT MODIFY */
package com.engineer4myanmar.json;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}