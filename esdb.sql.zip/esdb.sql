-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 22, 2015 at 10:57 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `esdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `info_id`) VALUES
(1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `name`) VALUES
(1, 'hotel'),
(2, 'bank'),
(3, 'restaurant'),
(4, 'hospital');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `time` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `history`
--


-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `hospital_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `price_high` decimal(10,2) NOT NULL,
  `price_low` decimal(10,2) NOT NULL,
  PRIMARY KEY (`hospital_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `info_id`, `price_high`, `price_low`) VALUES
(1, 7, '150.00', '50.00');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
  `hotel_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `price_high` decimal(10,2) NOT NULL,
  `price_low` decimal(10,2) NOT NULL,
  `cuisine` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotel_id`, `info_id`, `price_high`, `price_low`, `cuisine`) VALUES
(1, 3, '100.00', '10.00', 'Burmese'),
(21, 26, '300.00', '100.00', 'Thai'),
(3, 8, '100.00', '10.00', 'chinese'),
(4, 9, '200.00', '100.00', 'Burmese'),
(5, 10, '200.00', '100.00', 'Chinese'),
(6, 11, '200.00', '100.00', 'Burmese'),
(7, 12, '80.00', '30.00', 'Burmese'),
(8, 13, '200.00', '100.00', 'Thai'),
(9, 14, '100.00', '50.00', 'Burmese'),
(10, 15, '100.00', '50.00', 'Burmese'),
(11, 16, '100.00', '50.00', 'Burmese'),
(12, 17, '100.00', '50.00', 'Burmese'),
(13, 18, '300.00', '100.00', 'Japanese'),
(14, 19, '300.00', '100.00', 'Thai'),
(15, 20, '200.00', '100.00', 'Japanese'),
(16, 21, '150.00', '50.00', 'Thai'),
(17, 22, '300.00', '100.00', 'Japanese'),
(18, 23, '200.00', '100.00', 'Thai'),
(19, 24, '300.00', '100.00', 'Japanese'),
(20, 25, '150.00', '50.00', 'Burmese'),
(22, 27, '0.00', '0.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE IF NOT EXISTS `information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(6) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(125) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(2) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `ext_tb` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`id`, `cat_id`, `name`, `address`, `phone_no`, `url`, `rating`, `lat`, `lng`, `ext_tb`) VALUES
(3, 1, 'Aster Hotel', 'No.47/48 Mandalay Lashio Rd POL', '09253614647', 'www.agoda.com/Malang-Hotels', 2, 22.007845, 96.435928, 'hotel'),
(5, 2, 'Yoma Bank', 'No.3 Mandalay Lashio Rd POL', '085-22658', 'www.yomabank.com', 2, 22.024990, 96.461311, 'bank'),
(6, 3, 'Unicorn restaurant', 'Mandalay Lashio Road', '09796655847', '', 3, 22.015629, 96.448929, 'restaurant'),
(7, 4, 'General Hospital', 'No.158-B/5 Mandalay Lashio Rd POL', '085-65489', '', 3, 22.022306, 96.464417, 'hospital'),
(8, 1, 'pyin oo lwin', 'No4. shwe tg road', '409511212', 'njfdjfhdjfh', 3, 545.154419, 254.155502, 'hotel'),
(9, 1, 'Peace Land', 'Mandalay Lashio Road', '08522110', 'www.peacelandhotel.com', 2, 22.015862, 96.449417, 'hotel'),
(10, 1, 'Orchid Nan Myaing', 'Mandalay Lashio Road', '08523641', 'www.nanmyaing.com', 3, 22.015877, 96.450668, 'hotel'),
(11, 1, 'Essential', 'Sandar Road', '08521997', 'www.essential.com', 3, 22.013294, 96.454681, 'hotel'),
(12, 1, 'Monalisa', 'Mandalay Lashio Road', '08521568', 'www.monalisa.com', 1, 22.024298, 96.460663, 'hotel'),
(13, 1, 'Sakhan thar', 'Mandalay Lashio Road', '08523094', 'www.sakhanthar.com', 3, 22.024988, 96.461037, 'hotel'),
(14, 1, 'Hninn Si Khaing', 'Mandalay Lashio Road', '08522854', '-', 1, 22.029913, 96.468010, 'hotel'),
(15, 1, 'Royal Flower Guest House', 'Mandalay Lashio Road', '08523199', '-', 1, 22.030907, 96.471664, 'hotel'),
(16, 1, 'Hotel Smile', 'Mandalay Lashio Road', '08529467', '-', 1, 22.034912, 96.483398, 'hotel'),
(17, 1, 'San Pya', 'Mandalay Lashio Road', '08522694', '-', 1, 22.036819, 96.487907, 'hotel'),
(18, 1, 'Royal Reward Resort', 'Circular Road', '08528711', 'www.royalrewardresort.com', 5, 22.019770, 96.470314, 'hotel'),
(19, 1, 'Nan Taw Win', 'Mandalay Lashio Road', '08522943', 'www.nantawwin.com', 4, 22.016697, 96.469276, 'hotel'),
(20, 1, 'Royal Park View', 'Mandalay Lashio Road', '098601351', 'www.royalparkview.com', 3, 22.016001, 96.471611, 'hotel'),
(21, 1, 'Dehlia', 'Circular Road', '08521912', '-', 2, 22.014856, 96.474907, 'hotel'),
(22, 1, 'Hotel Pyin Oo Lwin', 'No.9 Nanda Road', '08521226', 'www.hotelpol.com', 5, 22.005098, 96.471786, 'hotel'),
(23, 1, 'Win Unity', 'Nanda Road', '08521438', '-', 2, 22.005386, 96.470177, 'hotel'),
(24, 1, 'Governor`s House', 'Mandalay Lashio Road', '08522657', 'www.governorhouse.com', 5, 22.020048, 96.458038, 'hotel'),
(25, 1, 'Grace Hotel', 'Mandalay Lashio Road', '08521669', '-', 3, 22.019798, 96.462303, 'hotel'),
(26, 1, 'Hoetl Maymyo', 'No.12 Yadana Street', '08528440', '-', 4, 22.028196, 96.464432, 'hotel');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `res_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) NOT NULL,
  `price_high` decimal(10,2) NOT NULL,
  `price_low` decimal(10,2) NOT NULL,
  `cuisine` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`res_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`res_id`, `info_id`, `price_high`, `price_low`, `cuisine`) VALUES
(1, 6, '100.00', '10.00', 'Burmese');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_email` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_password` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_phoneno` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_dob` date NOT NULL,
  `user_profession` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_city` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_phoneno`, `user_dob`, `user_profession`, `user_city`) VALUES
(1, 'aung', 'aung@gmail.com', '12345', '095506082', '1978-02-19', 'student', 'yangong'),
(2, 'koko', 'koko@gmail.com', '11111', '095506083', '1888-12-19', 'student', 'mandalay'),
(44, 'yezaw', 'yezaw@gmail.com', '12345', '56678888', '2015-07-06', 'doctor', 'ygn'),
(46, 'yezawmyint', 'yezaw@gmail.com', '12345', '0933327917', '1983-07-06', 'student', 'pyinoolwin'),
(47, 'soethant', 'soe@gmail.com', '123456', '2058054', '2015-03-20', 'dr', 'maymyo'),
(48, 'agag', 'ag@gmail.com', '12345', '098766544', '2015-07-07', 'dr', 'ygn'),
(49, 'phoneko', 'phoneko@gmail.com', '12345', '557788', '2015-06-07', 'doctor', 'ygn');
